# JEMA
Discord bot for university project
